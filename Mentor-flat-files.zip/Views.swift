import SwiftUI

// MARK: - Onboarding
struct OnboardingView: View {
    @EnvironmentObject var store: Store
    @State private var step = 0

    var body: some View {
        VStack(spacing: 24) {
            Spacer()
            Image(systemName: "sparkles").font(.system(size: 56)).foregroundStyle(.tint)
            Text("Meet your coach").font(.largeTitle.bold())

            Group {
                if step == 0 {
                    TextField("Your name", text: $store.profile.name)
                        .textFieldStyle(.roundedBorder)
                } else if step == 1 {
                    VStack(spacing: 12) {
                        ForEach(Focus.allCases) { f in
                            Button {
                                store.profile.focus = f
                            } label: {
                                HStack {
                                    Image(systemName: f.icon)
                                    Text(f.rawValue)
                                    Spacer()
                                    if store.profile.focus == f { Image(systemName: "checkmark.circle.fill") }
                                }
                                .padding()
                                .background(RoundedRectangle(cornerRadius: 14)
                                    .fill(store.profile.focus == f ? Color.accentColor.opacity(0.15) : Color(.secondarySystemBackground)))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                } else {
                    TextField("Why does this matter to you?", text: $store.profile.why, axis: .vertical)
                        .lineLimit(3...5)
                        .textFieldStyle(.roundedBorder)
                }
            }

            Spacer()
            Button {
                if step < 2 { step += 1 } else { store.finishOnboarding() }
            } label: {
                Text(step < 2 ? "Continue" : "Start").frame(maxWidth: .infinity).padding()
                    .background(Color.accentColor, in: RoundedRectangle(cornerRadius: 14))
                    .foregroundStyle(.white).font(.headline)
            }
        }
        .padding(24)
    }
}

// MARK: - Root
struct RootView: View {
    var body: some View {
        TabView {
            TodayView().tabItem { Label("Today", systemImage: "checkmark.circle") }
            CoachChatView().tabItem { Label("Coach", systemImage: "bubble.left.and.bubble.right") }
            ProgressTabView().tabItem { Label("Progress", systemImage: "chart.bar") }
        }
    }
}

// MARK: - Today
struct TodayView: View {
    @EnvironmentObject var store: Store
    @State private var showAdd = false
    @State private var newTitle = ""

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Today's plan").font(.headline)
                        ProgressView(value: store.todayProgress)
                        Text("\(Int(store.todayProgress * 100))% complete").font(.caption).foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 4)
                }
                Section {
                    ForEach(store.habits) { h in
                        Button { store.toggle(h) } label: {
                            HStack {
                                Image(systemName: h.isDone() ? "checkmark.circle.fill" : "circle")
                                    .foregroundStyle(h.isDone() ? Color.green : Color.secondary)
                                VStack(alignment: .leading) {
                                    Text(h.title).strikethrough(h.isDone())
                                    Text(h.focus.rawValue).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                if h.streak > 0 { Label("\(h.streak)", systemImage: "flame.fill").foregroundStyle(.orange).font(.subheadline) }
                            }
                        }
                        .buttonStyle(.plain)
                    }
                    .onDelete(perform: store.delete)
                }
            }
            .navigationTitle("Hi, \(store.profile.name.isEmpty ? "there" : store.profile.name)")
            .toolbar {
                Button { showAdd = true } label: { Image(systemName: "plus") }
            }
            .alert("New habit", isPresented: $showAdd) {
                TextField("Habit", text: $newTitle)
                Button("Add") {
                    if !newTitle.isEmpty { store.addHabit(newTitle, focus: store.profile.focus) }
                    newTitle = ""
                }
                Button("Cancel", role: .cancel) { newTitle = "" }
            }
        }
    }
}

// MARK: - Coach chat
struct CoachChatView: View {
    @EnvironmentObject var store: Store
    @State private var input = ""

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(spacing: 10) {
                            ForEach(store.messages) { m in
                                HStack {
                                    if m.role == "user" { Spacer(minLength: 48) }
                                    Text(m.text)
                                        .padding(12)
                                        .background(m.role == "user" ? Color.accentColor : Color(.secondarySystemBackground),
                                                    in: RoundedRectangle(cornerRadius: 16))
                                        .foregroundStyle(m.role == "user" ? Color.white : Color.primary)
                                    if m.role != "user" { Spacer(minLength: 48) }
                                }
                                .id(m.id)
                            }
                            if store.isSending { ProgressView().padding() }
                        }
                        .padding()
                    }
                    .onChange(of: store.messages.count) { _ in
                        if let last = store.messages.last { withAnimation { proxy.scrollTo(last.id, anchor: .bottom) } }
                    }
                }
                HStack {
                    TextField("Message your coach", text: $input, axis: .vertical)
                        .lineLimit(1...4)
                        .padding(10)
                        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 20))
                    Button {
                        let t = input; input = ""
                        Task { await store.send(t) }
                    } label: { Image(systemName: "arrow.up.circle.fill").font(.system(size: 32)) }
                    .disabled(input.trimmingCharacters(in: .whitespaces).isEmpty || store.isSending)
                }
                .padding()
            }
            .navigationTitle("Coach")
        }
    }
}

// MARK: - Progress
struct ProgressTabView: View {
    @EnvironmentObject var store: Store

    private var last7: [(String, Int)] {
        let cal = Calendar.current
        return (0..<7).reversed().map { offset in
            let d = cal.date(byAdding: .day, value: -offset, to: Date())!
            let n = store.habits.filter { $0.isDone(on: d) }.count
            let label = d.formatted(.dateTime.weekday(.abbreviated))
            return (label, n)
        }
    }

    var body: some View {
        NavigationStack {
            List {
                Section("Last 7 days") {
                    let maxV = max(store.habits.count, 1)
                    HStack(alignment: .bottom, spacing: 10) {
                        ForEach(last7, id: \.0) { item in
                            VStack {
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.accentColor)
                                    .frame(height: max(4, CGFloat(item.1) / CGFloat(maxV) * 100))
                                Text(item.0).font(.caption2)
                            }
                            .frame(maxWidth: .infinity)
                        }
                    }
                    .frame(height: 130, alignment: .bottom)
                }
                Section("Streaks") {
                    ForEach(store.habits.sorted { $0.streak > $1.streak }) { h in
                        HStack {
                            Text(h.title)
                            Spacer()
                            Label("\(h.streak)", systemImage: "flame.fill").foregroundStyle(.orange)
                        }
                    }
                }
            }
            .navigationTitle("Progress")
        }
    }
}
