import Foundation
import SwiftUI

final class Store: ObservableObject {
    @Published var profile = Profile() { didSet { save() } }
    @Published var habits: [Habit] = [] { didSet { save() } }
    @Published var messages: [ChatMessage] = [] { didSet { save() } }
    @Published var isSending = false

    private let key = "mentor.state.v1"
    private struct Snapshot: Codable {
        var profile: Profile
        var habits: [Habit]
        var messages: [ChatMessage]
    }

    init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let snap = try? JSONDecoder().decode(Snapshot.self, from: data) {
            profile = snap.profile
            habits = snap.habits
            messages = snap.messages
        }
    }

    private func save() {
        let snap = Snapshot(profile: profile, habits: habits, messages: messages)
        if let data = try? JSONEncoder().encode(snap) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    // MARK: Habits
    func toggle(_ habit: Habit) {
        guard let i = habits.firstIndex(where: { $0.id == habit.id }) else { return }
        let k = Habit.key(Date())
        if habits[i].doneDays.contains(k) { habits[i].doneDays.remove(k) }
        else { habits[i].doneDays.insert(k) }
    }

    func addHabit(_ title: String, focus: Focus) {
        habits.append(Habit(title: title, focus: focus))
    }

    func delete(at offsets: IndexSet) { habits.remove(atOffsets: offsets) }

    var todayProgress: Double {
        guard !habits.isEmpty else { return 0 }
        return Double(habits.filter { $0.isDone() }.count) / Double(habits.count)
    }

    // MARK: Daily plan
    func finishOnboarding() {
        profile.onboarded = true
        for t in Store.starterPlan(for: profile.focus) { addHabit(t, focus: profile.focus) }
        messages.append(ChatMessage(role: "assistant",
            text: "Hi \(profile.name.isEmpty ? "there" : profile.name). I'm your coach. I've set up a starter plan for \(profile.focus.rawValue.lowercased()). Tell me how today is going."))
    }

    static func starterPlan(for focus: Focus) -> [String] {
        switch focus {
        case .social: return ["Start one conversation with a stranger", "Hold eye contact for a full greeting", "Send one message to reconnect with a friend"]
        case .fitness: return ["20-minute workout", "Walk 8,000 steps", "Drink 2L of water"]
        case .style: return ["Lay out tomorrow's outfit", "Groom and skincare routine", "Stand and sit tall for 10 minutes"]
        case .mindset: return ["10 minutes of journaling", "Do one thing you've been avoiding", "No phone for the first 30 minutes of the day"]
        }
    }

    // MARK: Chat
    @MainActor
    func send(_ text: String) async {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, !isSending else { return }
        messages.append(ChatMessage(role: "user", text: trimmed))
        isSending = true
        let reply = await CoachService.reply(history: messages, profile: profile, habits: habits)
        messages.append(ChatMessage(role: "assistant", text: reply))
        isSending = false
    }
}
