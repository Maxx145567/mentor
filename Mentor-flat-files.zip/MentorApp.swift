import SwiftUI

@main
struct MentorApp: App {
    @StateObject private var store = Store()

    var body: some Scene {
        WindowGroup {
            if store.profile.onboarded {
                RootView().environmentObject(store)
            } else {
                OnboardingView().environmentObject(store)
            }
        }
    }
}
