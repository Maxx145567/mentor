import Foundation

enum Focus: String, Codable, CaseIterable, Identifiable {
    case social = "Social confidence"
    case fitness = "Fitness"
    case style = "Personal style"
    case mindset = "Mindset"
    var id: String { rawValue }
    var icon: String {
        switch self {
        case .social: return "person.2.fill"
        case .fitness: return "figure.run"
        case .style: return "tshirt.fill"
        case .mindset: return "brain.head.profile"
        }
    }
}

struct Profile: Codable {
    var name = ""
    var focus: Focus = .social
    var why = ""
    var onboarded = false
}

struct Habit: Identifiable, Codable {
    var id = UUID()
    var title: String
    var focus: Focus
    var doneDays: Set<String> = []   // "yyyy-MM-dd"

    static let fmt: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd"
        f.locale = Locale(identifier: "en_US_POSIX")
        return f
    }()

    static func key(_ d: Date) -> String { fmt.string(from: d) }

    func isDone(on d: Date = Date()) -> Bool { doneDays.contains(Habit.key(d)) }

    var streak: Int {
        var count = 0
        var day = Date()
        let cal = Calendar.current
        if !isDone(on: day) { day = cal.date(byAdding: .day, value: -1, to: day)! }
        while isDone(on: day) {
            count += 1
            day = cal.date(byAdding: .day, value: -1, to: day)!
        }
        return count
    }
}

struct ChatMessage: Identifiable, Codable {
    var id = UUID()
    var role: String   // "user" or "assistant"
    var text: String
}
