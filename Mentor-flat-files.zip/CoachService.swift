import Foundation

/// Talks to YOUR backend, which in turn calls an LLM API.
/// Never ship an API key inside the app binary: it can be extracted.
///
/// Expected backend contract:
///   POST <endpoint>
///   { "system": String, "messages": [ { "role": "user"|"assistant", "content": String } ] }
///   -> { "reply": String }
enum CoachService {
    // Set this to your own server URL (e.g. a small proxy on Cloudflare Workers / Vercel).
    static let endpoint = ""

    static func reply(history: [ChatMessage], profile: Profile, habits: [Habit]) async -> String {
        guard let url = URL(string: endpoint), !endpoint.isEmpty else {
            return offlineReply(history: history, habits: habits)
        }

        let done = habits.filter { $0.isDone() }.count
        let system = """
        You are a direct, supportive personal coach. The user is \(profile.name), focused on \(profile.focus.rawValue). \
        Their reason: \(profile.why). Today they completed \(done) of \(habits.count) habits. \
        Give short, practical, specific advice (under 120 words). Be honest, not flattering.
        """

        struct Body: Encodable {
            struct M: Encodable { let role: String; let content: String }
            let system: String
            let messages: [M]
        }
        struct Resp: Decodable { let reply: String }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.timeoutInterval = 30
        let body = Body(system: system,
                        messages: history.suffix(20).map { .init(role: $0.role, content: $0.text) })

        do {
            req.httpBody = try JSONEncoder().encode(body)
            let (data, resp) = try await URLSession.shared.data(for: req)
            guard (resp as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
            return try JSONDecoder().decode(Resp.self, from: data).reply
        } catch {
            return "I couldn't reach the coach service. Check your connection and try again."
        }
    }

    private static func offlineReply(history: [ChatMessage], habits: [Habit]) -> String {
        let remaining = habits.filter { !$0.isDone() }
        if let next = remaining.first {
            return "Offline mode: no AI backend is configured yet. For now, do this next: \"\(next.title)\". Small action beats perfect planning."
        }
        return "Offline mode: no AI backend is configured yet. You've finished today's habits. Rest, then plan tomorrow."
    }
}
